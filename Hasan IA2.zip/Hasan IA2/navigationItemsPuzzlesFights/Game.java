package navigationItemsPuzzlesFights;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Game
{
	private Scanner input = new Scanner(System.in);
	private Map map;

	public static void main(String[] args)
	{
		Game game = new Game();

		game.startGame();

		game.input.close();
	}

	private void startGame()
	{
		try
		{
			map = new Map();
			System.out.println(map.getCurrentRoomDescription());
		} catch (GameException e)
		{
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.exit(0);
		}

		while (true)
		{
			try
			{
				activateCommands();
			} catch (GameException e)
			{
				System.out.println(e.getMessage());
			}
		}

	}

	private void activateCommands() throws InvalidRoomException, InvalidItemException, InvalidPuzzleException
	{
		System.out.println("Enter Command:");
		String command = input.nextLine();
		String output = "";

		if (command.equals("Commands"))
		{
			System.out.println();// TODO list commands

		} else if (command.equalsIgnoreCase("N"))
		{
			output = map.movePlayerNorth();
		} else if (command.equalsIgnoreCase("S"))
		{
			output = map.movePlayerSouth();
		} else if (command.equalsIgnoreCase("E"))
		{
			output = map.movePlayerEast();
		} else if (command.equalsIgnoreCase("W"))
		{
			output = map.movePlayerWest();
		} 
		else if (command.equalsIgnoreCase("Inventory"))
		{
			output = map.getPlayerInventory().toString();
		} 
			else if (command.contains("pickup"))
		{
			map.pickupPlayerItem(command.split(" ")[1]);
		} else if (command.contains("drop"))
		{
			map.dropPlayerItem(command.split(" ")[1]);
		} else if (command.contains("inspect"))
		{
			output = map.inspectItem(command.split(" ")[1]);
		} else if (command.equalsIgnoreCase("explore"))
		{
			output = map.getRoomItems().toString();
		} 
		else
		{
			System.out.println("Please ented a valid command");
		}

		System.out.println(output);
		findPuzzle();
	}

	private void findPuzzle() throws InvalidPuzzleException 
	{		
		if (map.isCurrentRoomPuzzleSolved() == false)
		{
			for(int i = 0 ;i<map.getPuzzleAttempts() && map.isCurrentRoomPuzzleSolved() == false; i++)
			{
				System.out.println(map.getPuzzleQuestion());
				
				System.out.println(map.solveCurrentRoomPuzzle(input.nextLine()));
			}

		}
		
	}
}
