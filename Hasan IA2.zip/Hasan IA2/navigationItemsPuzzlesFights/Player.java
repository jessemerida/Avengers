package navigationItemsPuzzlesFights;

import java.util.ArrayList;

public class Player
{
	private ArrayList<String> items;
	
	public Player()
	{
		items = new ArrayList<String>();
	}
	
	public ArrayList<String> getInventory()
	{
		return items;
	}
		
}
