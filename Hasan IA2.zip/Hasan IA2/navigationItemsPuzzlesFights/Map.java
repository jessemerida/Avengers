package navigationItemsPuzzlesFights;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Map
{
	private Player player;
	private Room currentRoom;

	private ArrayList<Room> allRooms;
	private ArrayList<Item> allItems;
	private ArrayList<Puzzle> allPuzzles;

	public Map() throws FileNotFoundException, InvalidRoomException
	{
		allRooms = FileManager.readRooms("rooms2.txt");
		allItems = FileManager.readItems("items2.txt");
		allPuzzles = FileManager.readPuzzles("puzzles2.txt");

		player = new Player();
		currentRoom = getRoom("1");
	}

	private Room getRoom(String roomId) throws InvalidRoomException
	{
		if (roomId.equals("0"))
		{
			throw new InvalidRoomException("You cant go that direction");
		}

		Room room = null;
		for (int i = 0; i < allRooms.size(); i++)
		{
			if (allRooms.get(i).getRoomId().equals(roomId))
			{
				room = allRooms.get(i);
			}
		}
		return room;
	}

	private Item getItem(String itemName) throws InvalidItemException
	{

		Item item = null;
		for (int i = 0; i < allItems.size(); i++)
		{
			if (allItems.get(i).getItemName().equalsIgnoreCase(itemName))
			{
				item = allItems.get(i);
			}
		}

		if (item == null)
		{
			throw new InvalidItemException("This item is not here");
		}

		return item;
	}

	private Puzzle getPuzzle(String puzzleId) throws InvalidPuzzleException
	{
		Puzzle puzzle = null;

		for (int i = 0; i < allPuzzles.size(); i++)
		{
			if (allPuzzles.get(i).getId().equals(puzzleId))
			{
				puzzle = allPuzzles.get(i);
			}
		}

		if (puzzle == null)
		{
			throw new InvalidPuzzleException("There is no puzzle here");
		}

		return puzzle;
	}

	public String movePlayerNorth() throws InvalidRoomException
	{
		currentRoom.setVisited(true);
		currentRoom = getRoom(currentRoom.getNorthRoomID());
		return currentRoom.getDescription();
	}

	public String movePlayerEast() throws InvalidRoomException
	{
		currentRoom.setVisited(true);
		currentRoom = getRoom(currentRoom.getEastRoomID());
		return currentRoom.getDescription();
	}

	public String movePlayerSouth() throws InvalidRoomException
	{
		currentRoom.setVisited(true);
		currentRoom = getRoom(currentRoom.getSouthRoomID());
		return currentRoom.getDescription();
	}

	public String movePlayerWest() throws InvalidRoomException
	{
		currentRoom.setVisited(true);
		currentRoom = getRoom(currentRoom.getWestRoomID());
		return currentRoom.getDescription();
	}

	public String getCurrentRoomDescription()
	{
		return currentRoom.getDescription();
	}

	public ArrayList<String> getRoomItems()
	{
		return currentRoom.getItems();
	}

	public ArrayList<String> getPlayerInventory()
	{
		return player.getInventory();
	}

	public String inspectItem(String item) throws InvalidItemException
	{
		if (currentRoom.getItems().contains(item) || player.getInventory().contains(item))
		{
			throw new InvalidItemException("This item is not here");
		}
		return getItem(item).getDescription();
	}

	public void pickupPlayerItem(String item) throws InvalidItemException
	{
		player.getInventory().add(currentRoom.dropItem(item));
	}

	public String dropPlayerItem(String item) throws InvalidItemException
	{
		// TODO throw exception if item does not exist
		boolean itemExists = false;
		for (int i = 0; i < player.getInventory().size(); i++)
		{
			if (player.getInventory().get(i).equals(item))
			{
				itemExists = true;
			}
		}

		if (itemExists == false)
		{
			throw new InvalidItemException("This item is not here");
		}
		currentRoom.pickupItem(item);
		return player.getInventory().remove(player.getInventory().indexOf(item));
	}

	public boolean isCurrentRoomPuzzleSolved()
	{
		try
		{
			return getPuzzle(currentRoom.getPuzzleId()).isSolved();
		} catch (InvalidPuzzleException e)
		{
			return true;
		}
	}

	public String getPuzzleQuestion() throws InvalidPuzzleException
	{
		return getPuzzle(currentRoom.getPuzzleId()).getQuestion();
	}

	public String solveCurrentRoomPuzzle(String text) throws InvalidPuzzleException
	{
		return getPuzzle(currentRoom.getPuzzleId()).solvePuzzle(text);
	}

	public int getPuzzleAttempts() throws InvalidPuzzleException
	{
		return getPuzzle(currentRoom.getPuzzleId()).getAttempts();
	}

}