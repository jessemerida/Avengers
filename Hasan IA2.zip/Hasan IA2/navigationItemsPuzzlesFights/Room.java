package navigationItemsPuzzlesFights;

import java.util.ArrayList;

public class Room
{
	private String roomId;
	private boolean isVisited;
	private String description;
	private String descriptionVisited;
	private ArrayList<String> items;
	private String puzzleID;
	private String northRoomID;
	private String eastRoomID;
	private String southRoomID;
	private String westRoomID;

	public Room(String roomId, boolean isVisited, String description, String descriptionVisited, ArrayList<String> itemIDs, String puzzleID,
			String northRoomID,String eastRoomID, String southRoomID, String westRoomID)
	{
		this.roomId = roomId;
		this.isVisited = isVisited;
		this.description = description;
		this.descriptionVisited = descriptionVisited;
		this.items = itemIDs;
		this.puzzleID = puzzleID;
		this.northRoomID = northRoomID;
		this.eastRoomID = eastRoomID;
		this.southRoomID = southRoomID;
		this.westRoomID = westRoomID;
	}

	public boolean isVisited()
	{
		return isVisited;
	}

	public void setVisited(boolean isVisited)
	{
		this.isVisited = isVisited;
	}

	public String getDescription()
	{
		if(isVisited == true)
		{
			return descriptionVisited;
		}
		else
		{
			return description;
		}
		
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getRoomId()
	{
		return roomId;
	}

	public String getNorthRoomID()
	{
		return northRoomID;
	}

	public String getEastRoomID()
	{
		return eastRoomID;
	}

	public String getSouthRoomID()
	{
		return southRoomID;
	}

	public String getWestRoomID()
	{
		return westRoomID;
	}

	public void pickupItem(String item)
	{
		items.add(item);
	}

	public String dropItem(String item) throws InvalidItemException
	{
		boolean itemExists = false;
		for (int i = 0; i < items.size(); i++)
		{
			if (items.get(i).equals(item))
			{
				itemExists = true;
			}
		}
		
		if(itemExists == false)
		{
			throw new InvalidItemException("This item is not here");
		}
		return items.remove(items.indexOf(item));
	}

	public ArrayList<String> getItems()
	{
		return items;
	}
	
	public String getPuzzleId()
	{
		return puzzleID;
	}
}
