Welcome to Make Your Own Map!

MYOM is a program that allows you to create your own text-based game(as the name implies).
The program reads in a text files "map.txt", "items.txt", and "puzzles.txt" and constructs a map based your input.

---------------------------------------------------------------------------------------------------------------------

-> Open the file "rooms.txt"

Here, you will notice that each line is split in 7 parts: roomId~isVisted~roomDescription~2roomDescription~items~puzzleID~roomConnectionsIds

<roomID>
Room ID is the identification value given to the each room. Room Ids can never be duplicated.

<isVisited>
is Visted is a boolean value indicating whether a room has been visited or not

<roomDescription> 
Room description is the initial room's description. the system will retrieve this information when the player first enters a room.

<2roomDescription>
2nd room description is revisited the room's description. the system will retrieve this information when the player enters a room every other time. 

<items>
items is a list of items that the room contains. each entry can be separated by a comma. 0 indicates no items.

<puzzleID>
puzzleID is the identification string for a related puzzle. 0 indicates no puzzle.

<roomConnections>
Room connections is a list of 4 string values signifying the 4 connection points of each room.
the order is North, East, South, West. 0 indicates no connection (a wall).

There are 6 default rooms in the "rooms.txt" set up in the following format:
 ___ ___ 
|   |   |  
|_1_|_2_|
|	|   |
|_3_|_4_|
|   |   |   
|_5_|_6_|

--------------------------------------------------------------------------------------------------------------------

-> Open the file "items.txt"

Here, you will notice is that each line is split into 2 parts: itemName~itemDescription

<itemName> 
Item name is the name of the item. The player will use this name to interact with the items. itemName cannot be duplicated.
Note:if multiple items of the same type are wanted, it will use the same description. 

<itemDescription>
Item Description is the description of the item. The system will retrieve this description when the player inspects an item.

There are 3 default items in the "items.txt" file.

---------------------------------------------------------------------------------------------------------------------

-> Open the file "puzzles.txt" 

Here, you will notice that each line is split into 7 parts: puzzleId~puzzleQuestion~puzzleAnswer~puzzlePassmsg~puzzleFailedmsg~puzzleAttempts~isSolved

<puzzleId>
Puzzle Id is the identification given to each puzzle. Puzzle Ids can never be duplicated.

<puzzleQuestion>
Puzzle question is the question that will be asked to the user when the player comes across the puzzle.

<puzzleAnswer>
Puzzle answer is the expected answer to the above question.

<puzzlePassmsg>
Puzzle pass message is the message that will be printed when the puzzle is solved correctly

<puzzleFailedmsg>
Puzzle failed message is the message that will be printed when the puzzle is solved incorrectly

<puzzleAttempts>
Puzzle attempts is the number of attempts the player is allowed to answer the questions.

<isSolved>
is Solved is a boolean value to indicate if the puzzle has been solved.

There are 2 default puzzles in the "puzzles.txt" file. (in room 2 and room 6)