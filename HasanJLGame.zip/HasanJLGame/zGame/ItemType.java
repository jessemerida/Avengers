package zGame;

public enum ItemType
{
	WEAPON, ARMOR, CONSUMABLE, KEY;
}
